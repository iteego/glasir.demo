
public class MyClass { }