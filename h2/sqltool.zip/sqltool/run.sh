#!/bin/bash
java -jar sqltool_h2.jar --rcfile ./sqltool.rc h2
